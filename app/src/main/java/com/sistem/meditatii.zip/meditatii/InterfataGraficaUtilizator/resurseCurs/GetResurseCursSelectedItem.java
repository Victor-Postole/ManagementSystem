package com.sistem.meditatii.InterfataGraficaUtilizator.resurseCurs;

import com.sistem.meditatii.ModeleInterogareBazaDate.ResurseCurs.ResurseCursModel_INNER_JOIN;


public interface GetResurseCursSelectedItem {
    public void getSelectedItem(ResurseCursModel_INNER_JOIN insertPlataSesiuneModel);
}
