package com.sistem.meditatii.InterfataGraficaUtilizator.resursa;

import com.sistem.meditatii.ModeleInterogareBazaDate.InsertResursaDBModel;
import com.sistem.meditatii.ModeleInterogareBazaDate.InsertSesiuneMeditatieDBModel;

public interface GetResursaSelectedItem {
    public void getSelectedItem(InsertResursaDBModel insertResursaDBModel);
}
