package com.sistem.meditatii.InterfataGraficaUtilizator.angajareProfesor;

import com.sistem.meditatii.ModeleInterogareBazaDate.AngajareProfesor.AngajareProfesorModel_INNER_JOIN;

public interface GetAngajareProfesorSelectedItem {
    public void getSelectedItem(AngajareProfesorModel_INNER_JOIN angajareProfesorModel);
}
