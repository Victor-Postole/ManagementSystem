package com.sistem.meditatii.InterfataGraficaUtilizator.profesor;

import com.sistem.meditatii.ModeleInterogareBazaDate.InsertFacturaDBModel;

public interface GetProfesorSelectedItem {
    public void getSelectedItem(InsertFacturaDBModel.InsertProfesorDBModel insertProfesorDBModel);
}
