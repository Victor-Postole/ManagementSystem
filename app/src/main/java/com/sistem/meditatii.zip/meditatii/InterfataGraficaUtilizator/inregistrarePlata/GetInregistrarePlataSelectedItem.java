package com.sistem.meditatii.InterfataGraficaUtilizator.inregistrarePlata;

import com.sistem.meditatii.ModeleInterogareBazaDate.InregistrarePlati.InregistrarePlataModel_INNER_JOIN;

public interface GetInregistrarePlataSelectedItem {
    public void getSelectedItem(InregistrarePlataModel_INNER_JOIN insertInregistrarePlataDBModel);
}
