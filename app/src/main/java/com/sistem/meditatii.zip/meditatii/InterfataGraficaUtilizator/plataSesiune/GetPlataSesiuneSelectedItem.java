package com.sistem.meditatii.InterfataGraficaUtilizator.plataSesiune;

import com.sistem.meditatii.ModeleInterogareBazaDate.PlataSesiune.PlataSesiuneModel_INNER_JOIN;

public interface GetPlataSesiuneSelectedItem {
    public void getSelectedItem(PlataSesiuneModel_INNER_JOIN insertPlataSesiuneModel);
}
