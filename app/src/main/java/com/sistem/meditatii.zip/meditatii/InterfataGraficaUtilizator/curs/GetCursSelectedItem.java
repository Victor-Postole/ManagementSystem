package com.sistem.meditatii.InterfataGraficaUtilizator.curs;

import com.sistem.meditatii.ModeleInterogareBazaDate.InsertCursDBModel;
import com.sistem.meditatii.ModeleInterogareBazaDate.InsertPlataModel;

public interface GetCursSelectedItem {
    public void getSelectedItem(InsertCursDBModel insertCursDBModel);
}
