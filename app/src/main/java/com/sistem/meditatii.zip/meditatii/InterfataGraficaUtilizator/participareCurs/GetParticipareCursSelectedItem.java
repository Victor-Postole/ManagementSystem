package com.sistem.meditatii.InterfataGraficaUtilizator.participareCurs;

import com.sistem.meditatii.ModeleInterogareBazaDate.ParticipareCurs.ParticipareCursModel_INNER_JOIN;

public interface GetParticipareCursSelectedItem {
    public void getSelectedItem(ParticipareCursModel_INNER_JOIN insertPlataSesiuneModel);
}
