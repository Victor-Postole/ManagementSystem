package com.sistem.meditatii.InterfataGraficaUtilizator.plata;

import com.sistem.meditatii.ModeleInterogareBazaDate.InsertPlataModel;

public interface GetPlataSelectedItem {
    public void getSelectedItem(InsertPlataModel insertPlataModel);
}
