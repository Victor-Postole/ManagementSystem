package com.sistem.meditatii.InterfataGraficaUtilizator.factura;

import com.sistem.meditatii.ModeleInterogareBazaDate.InsertFacturaDBModel;

public interface GetSelectedItem {
    public void getSelectedItem(InsertFacturaDBModel insertFacturaDBModel);
}
