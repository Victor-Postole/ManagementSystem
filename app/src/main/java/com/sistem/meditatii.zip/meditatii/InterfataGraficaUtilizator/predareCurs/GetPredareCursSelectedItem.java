package com.sistem.meditatii.InterfataGraficaUtilizator.predareCurs;

import com.sistem.meditatii.ModeleInterogareBazaDate.PredareCursuri.PredareCursModel_INNER_JOIN;

public interface GetPredareCursSelectedItem {
    public void getSelectedItem(PredareCursModel_INNER_JOIN insertInregistrarePlataDBModel);
}
