package com.sistem.meditatii.InterfataGraficaUtilizator.resurseGenerareRapoarte;

import com.sistem.meditatii.ModeleInterogareBazaDate.ResurseCurs.ResurseCursModel_INNER_JOIN;
import com.sistem.meditatii.ModeleInterogareBazaDate.ResurseRaport.ResurseGenerareRapoarteModel_INNER_JOIN;


public interface GetResurseRaportSelectedItem {
    public void getSelectedItem(ResurseGenerareRapoarteModel_INNER_JOIN insertPlataSesiuneModel);
}
