package com.sistem.meditatii.InterfataGraficaUtilizator.utilizator;

import com.sistem.meditatii.ModeleInterogareBazaDate.InsertUtilizatorDBModel;

public interface GetUtilizatorSelectedItem {
    public void getSelectedItem(InsertUtilizatorDBModel insertUtilizatorDBModel);
}
