package com.sistem.meditatii.InterfataGraficaUtilizator.contUtilizator;

import com.sistem.meditatii.ModeleInterogareBazaDate.ContUtilizator.ContUtilizatorModel_INNER_JOIN;

public interface GetContUtilizatorSelectedItem {
    public void getSelectedItem(ContUtilizatorModel_INNER_JOIN insertPlataSesiuneModel);
}
