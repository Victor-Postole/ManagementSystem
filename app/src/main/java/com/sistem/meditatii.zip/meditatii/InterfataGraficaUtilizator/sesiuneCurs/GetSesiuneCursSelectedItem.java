package com.sistem.meditatii.InterfataGraficaUtilizator.sesiuneCurs;

import com.sistem.meditatii.ModeleInterogareBazaDate.SesiuneCurs.SesiuneCursModel_INNER_JOIN;

public interface GetSesiuneCursSelectedItem {
    public void getSelectedItem(SesiuneCursModel_INNER_JOIN insertPlataSesiuneModel);
}
