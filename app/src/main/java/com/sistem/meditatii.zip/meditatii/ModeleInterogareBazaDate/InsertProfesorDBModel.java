package com.sistem.meditatii.ModeleInterogareBazaDate;


public class InsertProfesorDBModel {
}
