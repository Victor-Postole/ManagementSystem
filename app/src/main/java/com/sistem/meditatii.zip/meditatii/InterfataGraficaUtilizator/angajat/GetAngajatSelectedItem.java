package com.sistem.meditatii.InterfataGraficaUtilizator.angajat;

import com.sistem.meditatii.ModeleInterogareBazaDate.InsertAngajatDBModel;
import com.sistem.meditatii.ModeleInterogareBazaDate.InsertFacturaDBModel;

public interface GetAngajatSelectedItem {
    public void getSelectedItem(InsertAngajatDBModel insertAngajatDBModel);
}
