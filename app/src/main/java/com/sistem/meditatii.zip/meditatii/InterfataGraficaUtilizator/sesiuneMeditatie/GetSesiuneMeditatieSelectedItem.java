package com.sistem.meditatii.InterfataGraficaUtilizator.sesiuneMeditatie;

import com.sistem.meditatii.ModeleInterogareBazaDate.InsertSesiuneMeditatieDBModel;

public interface GetSesiuneMeditatieSelectedItem {
    public void getSelectedItem(InsertSesiuneMeditatieDBModel insertSesiuneMeditatieDBModel);
}
