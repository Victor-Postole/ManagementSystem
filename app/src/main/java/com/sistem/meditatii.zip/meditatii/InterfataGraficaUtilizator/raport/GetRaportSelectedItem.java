package com.sistem.meditatii.InterfataGraficaUtilizator.raport;

import com.sistem.meditatii.ModeleInterogareBazaDate.InsertFacturaDBModel;
import com.sistem.meditatii.ModeleInterogareBazaDate.InsertRaportDBModel;

public interface GetRaportSelectedItem {
    public void getSelectedItem(InsertRaportDBModel insertRaportDBModel);
}
