package com.sistem.meditatii.InterfataGraficaUtilizator.student;

import com.sistem.meditatii.ModeleInterogareBazaDate.InsertStudentDBModel;

public interface GetStudentSelectedItem {
    public void getSelectedItem(InsertStudentDBModel insertStudentDBModel);
}
